const SpotifyWebApi = require('spotify-web-api-node');
const express = require('express');
const app = express();
const cors = require('cors');

// Adding middleware
app.use(cors());

// Set up the Spotify API credentials (replace these with your own)
const spotifyApi = new SpotifyWebApi({
	clientId: '74f1ad1416024d098678c349a9d82873',
	clientSecret: '3500485dfc1e433da89b0d0e2de26a60',
	redirectUri: 'http://localhost:5173/',
});

// Get an access token
async function getAccessToken() {
	const data = await spotifyApi.clientCredentialsGrant();
	return data.body['access_token'];
}

// Search for a track by name
async function searchTrackByName(trackName) {
	const accessToken = await getAccessToken();
	spotifyApi.setAccessToken(accessToken);
	const data = await spotifyApi.searchTracks(trackName, { limit: 1 });
	return data.body.tracks.items[0];
}
// Search for a track by name and return the track ID
async function getTrackId(trackName) {
	try {
		const result = await spotifyApi.searchTracks(trackName);
		const trackId = result.body.tracks.items[0].id;
		return trackId;
	} catch (err) {
		return null;
	}
}
// Get the audio features for a track
async function getAudioFeaturesForTrack(trackId) {
	const accessToken = await getAccessToken();
	spotifyApi.setAccessToken(accessToken);
	const data = await spotifyApi.getAudioFeaturesForTrack(trackId);
	return data.body;
}

// Get the key and tempo for a track by name
async function getKeyAndTempoForTrack(trackName) {
	const track = await searchTrackByName(trackName);

	// set track key and tempo to be -1 if no track is found
	if (typeof track === 'undefined') {
		return {
			trackName: trackName,
			key: -1,
			tempo: -1,
		};
	}

	// return key and tempo otherwise
	const audioFeatures = await getAudioFeaturesForTrack(track.id);
	return {
		trackName: trackName,
		key: audioFeatures.key,
		tempo: audioFeatures.tempo,
	};
}
// Search for tracks with same keys and bpm
// return tracks (and the artists) that have a similar key and bpm to the provided track
async function searchTracksWithSimilarKeysAndBPM(trackName) {
	// Get the key and tempo for the provided track
	const { key, tempo } = await getKeyAndTempoForTrack(trackName);
	// Get the track ID for the provided track
	const trackId = await getTrackId(trackName);
	if (trackId === null) {
		return null;
	}

	// Get recommendations based on the key and tempo of the provided track
	const searchResults = await spotifyApi.getRecommendations({
		seed_tracks: [trackId],
		target_key: key,
		target_tempo: tempo,
		limit: 20,
	});
	// Returns an array of 20 tracks that are similar to the provided track
	const results = await Promise.all(
		searchResults.body.tracks.map(async (track) => {
			const audioFeatures = await getAudioFeaturesForTrack(track.id);
			return {
				name: track.name,
				bpm: audioFeatures.tempo,
				mode: audioFeatures.mode,
				artist: track.artists[0].name, // Assuming the first artist is the main one
				key: audioFeatures.key,
				time_signature: audioFeatures.time_signature,
				uri: audioFeatures.uri,
				id: Math.random(1)
			};
		})
	);
	return results;
}

// Method to test out the searchTracksWithSimilarKeysAndBPM function
// Print the names of the tracks that have similar keys and bpm to the provided track
async function printTrackNames(trackName) {
	const tracks = await searchTracksWithSimilarKeysAndBPM(trackName);
	if (tracks === null) {
		console.log('This track was unrecognized in the spotify data base.');
		return;
	}
	tracks.forEach((track) => {
		console.log(`${track.name} by ${track.artists[0].name}`);
	});
}
// Prints the array of tracks that have similar keys and bpm to the provided track
async function printTracksArray(trackName) {
	const tracks = await searchTracksWithSimilarKeysAndBPM(trackName);
	if (tracks === null) {
		console.log('This track was unrecognized in the spotify data base.');
		return;
	}
	console.log(tracks[0]);
}

printTracksArray("I'm a Believer");

app.use(express.json());

app.get('/api/songs', async (req, res) => {
	const trackName = req.query.title;
	console.log(req);
	try {
		const track = await searchTracksWithSimilarKeysAndBPM(trackName);
		res.json(track);
	} catch (err) {
		res
			.status(500)
			.json({ error: 'An error occurred while searching for the track.' });
	}
});

app.listen(8000, () =>
	console.log('Server is running on http://localhost:8000')
);
