import React from 'react';




function SearchBar(props) {
    return (
        <form onSubmit={props.search}>
            <input type="text" value={props.query} onChange={props.handleChange}/>
            <input type="submit" value="Submit"/>
        </form>
    )
}

export default SearchBar;