import React from 'react';

function SongRecord(props) {
  const { name, artist, bpm, scale } = props;

  return (
    <div className="song-record">
      <h2>{name}</h2>
      <p>Artist: {artist}</p>
      <p>BPM: {bpm}</p>
      <p>Key: {scale}</p>
    </div>
  );
}

export default SongRecord;