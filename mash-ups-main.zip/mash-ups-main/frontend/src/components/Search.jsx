import React from 'react';
import SearchBar from './SearchBar';
import {useState} from 'react';
import SongRecord from './SongRecord.jsx';
import axios from 'axios';

const BACKEND_URL = "http://localhost:8000/api/songs";

function Search() {
    const [query, setQuery] = useState("");
    const [songRecords, setSongRecords] = useState([]);

    function onSearchQueryChange(event) {
        setQuery(event.target.value);
    }

    async function search(event) {
        event.preventDefault();
        const response = await axios.get(BACKEND_URL, {
            params : {
                title: query
            }
        })
        
        setSongRecords(response.data);
    }

    console.log(songRecords);

    return (
        <>
            <SearchBar setSongRecords={setSongRecords} query={query} handleChange={onSearchQueryChange} search={search}/>
            <div>
                {
                    songRecords.map((song) => {
                        return (
                            <SongRecord name={song.name} artist={song.artist} bpm={song.bpm} key={song.id} scale={song.key}/>
                        )
                    })
                }
            </div>
        </>
        
    );
};

export default Search;